package tracker;


import java.awt.Color;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class AreaDeCalor {
    
    public void coloreArea(int cor, JPanel _painel){
        
        Color minhaCor = determinaCor(cor);        
        _painel.setForeground(minhaCor);
    }
    
    public Color determinaCor(int indiceCor){
        Color cor = null;
        switch(indiceCor){
            case 1:
                cor = Color.green;
                break;
            case 2:
                cor = Color.yellow;
                break;
            case 3:
                cor = Color.red;
                break;
        }
        return cor;
    }
}
