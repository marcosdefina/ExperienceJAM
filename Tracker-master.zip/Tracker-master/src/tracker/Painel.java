package tracker;


import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Painel {
    ArrayList<JPanel> paineis;
    int painelAtual;
    
    public Painel(int _painelAtual){
        painelAtual = _painelAtual;
    }
    
    public void listar(JPanel[] container){
        Component[] comp;
        for(JPanel cont:container){
            comp = cont.getComponents();
            //System.out.println(comp.length);
            System.out.println(comp[0].getName());
            System.out.println(comp[1].getName());
            System.out.println(comp[2].getName());
            System.out.println(comp[3].getName());
//            for(int i = 0; i < comp.length; i++){
//                System.out.println(comp[i].getName());
//                //paineis.add((JPanel)comp[i]);
//                
//            }            
        }               
    }
    
    public void colorir(Color color){
        paineis.get(painelAtual).setBackground(color);
    }
    
}
